Carrier Founder Physics MCQ Package

File: physics.json
Questions: 20 bilingual Physics MCQs
Topics: Motion, graphs, vectors and projectile motion
Equations are formatted with MathJax where required.
The source PDF did not include an answer key; correct options were solved and verified from Physics concepts.
